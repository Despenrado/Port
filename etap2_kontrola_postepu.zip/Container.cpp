#include "Container.h"

Container::Container(int id) {
    this->id = id;
    this->isSend = false;
}
Container::Container() {}