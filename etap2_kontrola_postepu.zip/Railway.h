#pragma once

using namespace std;

class Railway
{
private:
    /* data */
public:
    int id;
    bool isBusy;
    int trainID;

    Railway();
};
