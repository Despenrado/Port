#pragma once
#include "Train.h"

Train::Train() {}