#pragma once

class TrainStation
{
private:
    /* data */
public:
    int railwayID;

    TrainStation();
};
